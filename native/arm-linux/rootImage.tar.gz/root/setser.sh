
# setser.sh - configures serial device /dev/ttySXn on sidearm
#             including configuration of DPA tranceivers and 
#             SPI bus.

# Check args and print use message if invalid
if ( [[ -z $1 ]] || [[ -z $2 ]] ) then
echo usage: sh $0 port[0:7] speed 
exit
fi

# Compute DPA configuration commands:
# SPI chip select
let CS=$1/2
let CSCMD=$CS
# COMM relay isolation 
let X=$1%2+2
let COMRELA=$X"000"
let COMRELB=$X"001"
# COMM power 
let Y=$1%2+6
let COMPWR=$Y"032"

echo cmds are "$CSCMD""Q" "$COMRELA""=" "$COMRELB""=" "$COMPWR""="

# Send SPI config string:
# 16 bit words, use SPI port, 256 clock divisor,no loopback
# normal clock phase, uninerted clock,no device selected
echo 10W0G100S0L0P0I7Q > /dev/spi
sleep 1
# Send DPA Commands
echo $CSCMD"Q" > /dev/spi
sleep 1
echo $COMRELA"=" > /dev/spi
sleep 1
echo $COMRELB"=" > /dev/spi
sleep 1
echo $COMPWR"=" > /dev/spi
sleep 1

# Set up /dev/ttySXn speed and flow control
echo setting /dev/ttySX$1 speed=$2
stty -F/dev/ttySX$1 speed $2 clocal

echo done
