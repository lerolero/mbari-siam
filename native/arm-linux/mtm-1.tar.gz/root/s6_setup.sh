mount /dev/hda1
#mount tempest:/vol/vol0/users/oreilly

sh lspi.sh
alias ll='ls -l'
chgrp lock /var/lock
chmod 775 /var/lock

