device=ttySX
major=19
mknod /dev/${device}0 c $major 0
mknod /dev/${device}1 c $major 1
mknod /dev/${device}2 c $major 2
mknod /dev/${device}3 c $major 3
mknod /dev/${device}4 c $major 4
mknod /dev/${device}5 c $major 5
mknod /dev/${device}6 c $major 6
mknod /dev/${device}7 c $major 7
mknod /dev/${device}8 c $major 8
mknod /dev/${device}9 c $major 9
mknod /dev/${device}10 c $major 10
mknod /dev/${device}11 c $major 11
mknod /dev/${device}12 c $major 12
mknod /dev/${device}13 c $major 13
mknod /dev/${device}14 c $major 14
mknod /dev/${device}15 c $major 15
