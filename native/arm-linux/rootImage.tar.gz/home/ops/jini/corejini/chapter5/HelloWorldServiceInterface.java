// This is the interface that the proxy implements

package corejini.chapter5;

public interface HelloWorldServiceInterface {
    public String getMessage();
}

