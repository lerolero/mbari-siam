#!/bin/bash
#
# Script to set ownership and privs of various files needed by SIAM
# NOTE - You must be root to execute this script
#

cd /root
chown root suspend
if [ $? -ne 0 ]; then
    echo "You must be root to run this script!"
    exit 1
fi
chgrp root suspend
chmod 4755 suspend

chown root suspend.sh
chgrp root suspend.sh
chmod 4755 suspend.sh

chown root setPWER
chgrp root setPWER
chmod 4755 setPWER

chown root ricohRTC
chgrp root ricohRTC
chmod 4755 ricohRTC

cd /etc
chown root auxTelem.sh
chgrp root auxTelem.sh
chmod 755 auxTelem.sh 

chown root hosts
chgrp root hosts
chmod 644 hosts

chown root profile
chgrp root profile
chmod 644 profile

cd /etc/siam
chown root siamEnv
chgrp root siamEnv
chmod 755 siamEnv

chown root siamapp
chgrp root siamapp
chmod 755 siamapp

chown root manageLog
chgrp root manageLog
chmod 755 manageLog

chown root manageSyslog
chgrp root manageSyslog
chmod 755 manageSyslog

cd /etc/ppp/peers
chown root longhaul
chgrp root longhaul

cd /usr/sbin
chown root ntpdate
chgrp lock ntpdate
chmod 4755 ntpdate

chown root pppd
chgrp lock pppd
chmod 4755 pppd

chown root pon
chgrp root pon
chmod 755 pon

chown root poff
chgrp root poff
chmod 755 poff

chown root plog
chgrp root plog
chmod 755 plog

chown root plogfast
chgrp root plogfast
chmod 755 plogfast

chown root plogslow
chgrp root plogslow
chmod 755 plogslow
