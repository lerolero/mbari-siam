// Creates a backend remote object for the service to communicate
// with

package corejini.chapter5;

import net.jini.core.lookup.ServiceItem;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


// BackendService is the "wrapper" application that creates
// a remote object and publishes a proxy that can talk to it.
public class BackendService
    extends LeasedService {

    // Backend is the RMI server object that receives remote method 
    // invocations from the proxy. It simply cycles through a set of
    // strings each time it is called.
    static class Backend extends UnicastRemoteObject 
	implements BackendProtocol {

	protected int _nextMessage = 0;
	protected String[] _messages = {"I didn't expect",
				       "a sort of",
				       "\"Spanish Inquisition\"!"};

	// Nothing for the constructor to do but let the superclass
	// constructor run
	Backend() throws RemoteException {
	}

	// Get the next string
	public String fetchString() throws RemoteException {
	    System.out.println("Backend.fetchString()...");
	    String string = _messages[_nextMessage];
	    _nextMessage = (_nextMessage + 1) % _messages.length;

	    return string;
	}
    }


    // Constructor just lets superclass constructor run
    public BackendService() throws IOException {
    }


    // Since we're using a different proxy, we have to reimplement
    // createProxy(). This version creates a remote server object that
    // will receive method invocations from the proxy, and creates a
    // HelloWorldServiceProxy2 object that refers to it.
    protected HelloWorldServiceInterface createProxy() {
	try {
	    BackendProtocol backend = new Backend();
	    return new HelloWorldServiceProxy2(backend);
	}
	catch (RemoteException exception) {
	    System.err.println("Error creating backend: " + 
			       exception.getMessage());
	    exception.printStackTrace();
	    System.exit(1);

	    // Not reached
	    return null;
	}
    }

    // main() creates the wrapper and starts the lease thread
    public static void main(String args[]) {
	try {
	    BackendService service = 
		new BackendService();

	    service._leaseThread = new Thread(service);
	    service._leaseThread.start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create service: " + 
			       exception.getMessage());
	}
    }
}

