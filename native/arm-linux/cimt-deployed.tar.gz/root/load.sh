insmod -o xr788_0 xr788.o
insmod -o xr788_1 xr788.o chipbase=0x10000200 chipirq=3 firstminor=8
