#!/bin/bash
#
# Startup script to control power to the Short Haul RF Link
#
# This script is normally called from an entry in /etc/inittab, e.g.
# T13:23:respawn:/etc/auxTelem.sh &>/dev/null
#
# Usage:  auxTelem.sh <-d device> <-b baud> <-t timeout> <-y term_emulation> \
#		<-p powerBit> <-s sleepTime>
# where
# "-d device"	refers to the ttyxxx device to perform a getty on.
#		Leave off the leading "/dev/"
# "-b baud"	is the baud rate to talk to the serial device (radio)
# "-t timeout"	is the timeout passed to getty.  This is the amount of
#		time the radio will be on, allowing the user to log in
# "-y term_emulation" - This is the value, passed through getty, that
#		        eventually is put into your TERM variable
# "-p powerBit"	Radio power bit, passed to "rfpower" to turn on radio
# "-s sleepTime" Amount of time script goes to sleep after getty times out.
#		 This, then, becomes the radio "off" time.
#

declare device="ttySX13"
let baud=115200
let timeout=30
declare term=""
let powerBit=0
let sleepTime=300

#Process command-line options
while getopts "b:d:p:s:t:y:" OPTION
do
    case $OPTION in
        b) let baud=$OPTARG
	;;
        d) declare device=$OPTARG
	;;
        p) if [ $OPTARG -lt 0 -o $OPTARG -gt 1 ]
	   then
	       echo "Bad value for Power Bit (-p)"
	   else
	       let powerBit=$OPTARG
	   fi
	;;
        s) let sleepTime=$OPTARG
	;;
        t) let timeout=$OPTARG
	;;
        y) declare term=$OPTARG
	;;
    esac
done

# Turn on RF Power
/mnt/hda/siam/utils/rfpower $powerBit ON

# Let Radio data-link connect before getty tries to use it
sleep 3

# Run getty with timeout, prints login prompt to user
/sbin/getty -t $timeout $device $baud $term

# Let radio send last characters before cutting off power
sleep 3

# Turn off RF power
/mnt/hda/siam/utils/rfpower $powerBit OFF

# This 'sleep' gives us our "off" time before this script exits
# and inittab reruns it from the top.
sleep $sleepTime
