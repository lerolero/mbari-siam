// A "smarter" proxy for the HelloWorldService. This one knows how to
// talk to a remote object that implements the BackendProtocol.

package corejini.chapter5;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;


public class HelloWorldServiceProxy2
    implements HelloWorldServiceInterface, Serializable
{
    protected BackendProtocol _backend;

    public HelloWorldServiceProxy2() {
    }


    public HelloWorldServiceProxy2(BackendProtocol backend) {
	_backend = backend;
    }


    // Note that getMessage() now calls _backend.fetchString()
    public String getMessage() {
	try {
	    return _backend.fetchString();
	}
	catch (RemoteException exception) {
	    return "Couldn't contact backend: " + exception.getMessage();
	}
    }
}

