# setup.sh - load modules and environment info
#            Loads SPI and registers modules
#            Mounts the compact flash
#            sets Java environment

mount /dev/hda1 /mnt/hda
sh /root/lspi.sh
insmod registers
cd /mnt/hda
. iveEnv.sh

