// Extend HelloWorldClient so it can respond to new services

package corejini.chapter5;

import net.jini.core.lookup.ServiceEvent;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.RemoteEventListener;
import net.jini.core.event.UnknownEventException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class EventClient extends HelloWorldClient {

    // 10 minute lease
    protected final int LEASE_TIME = 10 * 60 * 1000;

    // Inner Listener class
    class EventListener 
	extends UnicastRemoteObject 
	implements RemoteEventListener {
	
	public EventListener() throws RemoteException {
	}

	// Called by LookupService when HelloWorldService appears
	public void notify(RemoteEvent event) 
	    throws RemoteException, UnknownEventException {
	    System.out.println("Got an event from " + event.getSource());

	    if (event instanceof ServiceEvent) {
		ServiceEvent serviceEvent = (ServiceEvent )event;
		ServiceItem item = serviceEvent.getServiceItem();
		HelloWorldServiceInterface hello = 
		    (HelloWorldServiceInterface )item.service;

		System.out.println("Found a service.");
		System.out.println("Its message is: " + hello.getMessage());
	    }
	    else {
		System.out.println("Not a service event; ignore it");
	    }
	}
    }

    protected EventListener _eventListener;

    // Same as superclass, except create an EventListener
    public EventClient() throws RemoteException, IOException {
	_eventListener = new EventListener();
    }


    // Register interest in events from LookupService that involve
    // HelloWorldService objects
    protected Object lookForService(ServiceRegistrar lookupService) {
	Object object = super.lookForService(lookupService);

	if (object != null) {
	    // Found HelloWorldServiceInterface in lookupService
	    return object;
	}
	else {
	    // LookupService doesn't yet contain any HelloWorldService 
	    // objects
	    try {
		// Ask for events from lookupService that involve 
		// HelloWorldService objects
		registerForEvents(lookupService);
	    }
	    catch (RemoteException exception) {
		System.err.println("Can't solicit events: " + 
				   exception.getMessage());

		// Discard service, so we don't see it again
		_discovery.discard(lookupService);
	    }
	    finally {
		return null;
	    }
	}
    }


    // Ask for events from the LookupService that involve HelloWorldService
    // objects.
    protected void registerForEvents(ServiceRegistrar lookupService) 
	throws RemoteException {
	System.out.println("EventClient.registerForEvents()...");
	// Call our EventListener when a LookupService change involving 
	// HelloWorldService object occurs.
	lookupService.notify(_template, 
			     ServiceRegistrar.TRANSITION_NOMATCH_MATCH,
			     _eventListener, null, LEASE_TIME);
    }


    // Start the client
    public static void main(String args[]) {
	try {
	    EventClient client = new EventClient();
	    new Thread(client).start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create client: " + 
			       exception.getMessage());
	}
    }
}

