// A client of the HelloWorldService

package corejini.chapter5;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

public class HelloWorldClient implements Runnable {
    protected ServiceTemplate _template;
    protected LookupDiscovery _discovery;

    // An inner class to implement DiscoveryLister
    class Listener implements DiscoveryListener {

	public void discovered(DiscoveryEvent event) {

	    System.out.println("HelloWorldClient - discovered lookup service");

	    ServiceRegistrar[] newregs = event.getRegistrars();
	    for (int i = 0; i < newregs.length; i++) {
		lookForService(newregs[i]);
	    }
	}

	public void discarded(DiscoveryEvent event) {
	    // Does nothing 
	}

    }

    public HelloWorldClient() throws IOException {
	// ???
	Class[] types = {HelloWorldServiceInterface.class};

	_template = new ServiceTemplate(null, types, null);

	// Set a SecurityManager
	if (System.getSecurityManager() == null) {
	    System.setSecurityManager(new RMISecurityManager());
	}

	// Search the public group
	_discovery = new LookupDiscovery(new String[] {""});

	// Install our listener
	System.out.println("HelloWorldClient - install DiscoveryListener");
	_discovery.addDiscoveryListener(new Listener());
    }


    // Once we've found a LookupService, look for proxies that 
    // implement the HelloWorldServiceInterface
    protected Object lookForService(ServiceRegistrar lookupService) {
	Object o = null;

	try {
	    o = lookupService.lookup(_template);
	}
	catch (RemoteException exception) {
	    System.err.println("Error doing lookup: " + 
			       exception.getMessage());
	    return null;
	}

	if (o == null) {
	    System.err.println("No matching service");
	    return null;
	}

	System.out.println("Service message: " + 
			   ((HelloWorldServiceInterface )o).getMessage());

	return o;
    }


    // This thread just keeps the VM running (we have no GUI)
    public void run() {
	while (true) {
	    try {
		Thread.sleep(1000000);
	    }
	    catch (InterruptedException exception) {
	    }
	}
    }

    // Create a HelloWorldClient and start its thread
    public static void main(String args[]) {
	try {
	    HelloWorldClient client = new HelloWorldClient();
	    new Thread(client).start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create client: " + 
			       exception.getMessage());
	}
    }
}
