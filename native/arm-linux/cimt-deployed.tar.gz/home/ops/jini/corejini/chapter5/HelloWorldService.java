package corejini.chapter5;

import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.discovery.LookupDiscovery;
import net.jini.core.lookup.ServiceItem;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import java.util.HashMap;
import java.util.Iterator;
import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;


// This is the proxy object which gets downloaded by clients.
// It has to be Serializable, since it gets sent to a LookupService,
// and then from there to clients. It implements 
// HelloWorldServiceInterface; clients can search a LookupService for
// proxies that implement this interface.
class HelloWorldServiceProxy implements Serializable, 
					HelloWorldServiceInterface {

    // No arguments to constructor
    public HelloWorldServiceProxy() {
    }

    public String getMessage() {
	return "Hello, sailor!";
    }
}



// HelloWorldService is a "wrapper" class that finds LookupServices
// and publishes the HelloWorldServiceProxy.
public class HelloWorldService implements Runnable {

    // Lease for 10 minutes
    protected final int LEASE_TIME = 10 * 60 * 1000;

    protected HashMap _registrations = new HashMap();
    protected ServiceItem _item;
    protected LookupDiscovery _lookupDiscovery;

    // Inner class to listen for discoveries
    class Listener implements DiscoveryListener {

	// Called when a new LookupService has been found
	public void discovered(DiscoveryEvent event) {
	    System.out.println("Discovered a lookup service");
	    ServiceRegistrar[] newregs = event.getRegistrars();

	    // Register any new registrars
	    for (int i = 0; i < newregs.length; i++) {
		if (!_registrations.containsKey(newregs[i])) {
		    // This is a new LookupService; add it to our list
		    registerWithLookup(newregs[i]);
		}
	    }
	}


	// Called only when a LookupService has been explicitly discarded,
	// not automatically when a lookup service goes down. Once 
	// discovered, there is no ongoing communication with a lookup
	// service.
	public void discarded(DiscoveryEvent event) {
	    ServiceRegistrar[] deadregs = event.getRegistrars();

	    for (int i = 0; i < deadregs.length; i++) {
		// Remove LookupService from our list
		_registrations.remove(deadregs[i]);
	    }
	}
    }


    public HelloWorldService() throws IOException {

	System.out.println("HelloWorldService()...");

	System.out.println("HelloWorldService() - create service item");
	// Create the ServiceItem, which is passed to LookupServices during
        // registration.
	_item = new ServiceItem(null, createProxy(), null);

	// Set a security manager, since we'll be downloading LookupService
        // proxies.
	System.out.println("HelloWorldService() - set security manager");

	if (System.getSecurityManager() == null) {
	    System.setSecurityManager(new RMISecurityManager());
	}

	// Search for the public group, which by convention is named
	// by the empty string
	System.out.println("HelloWorldService() - search for public group");
	_lookupDiscovery = new LookupDiscovery(new String[] {""});

	// Install our listener, which is notified when a new LookupService
	// is found by the JINI discovery subsystem.
	System.out.println("HelloWorldService() - install listener");
	_lookupDiscovery.addDiscoveryListener(new Listener());
    }


    protected HelloWorldServiceInterface createProxy() {
	return new HelloWorldServiceProxy();
    }


    synchronized void registerWithLookup(ServiceRegistrar lookupService) {

	ServiceRegistration registration = null;
	Object object;

        // Register our service with the LookupService
	try {
	    object = lookupService.register(_item, LEASE_TIME);
	    registration = (ServiceRegistration )object;
	}
	catch (RemoteException exception) {
	    System.out.println("Couldn't register: " + exception.getMessage());
	    return;
	}

	// If this is the first registration, use the service ID
	// returned to us.
	if (_item.serviceID == null) {
	    _item.serviceID = registration.getServiceID();
	    System.out.println("Set service ID to " + _item.serviceID);
	}

	System.out.println("adding object to _registrations: " 
			   + object.getClass().getName());

	if (object instanceof ServiceRegistration) {
	    System.out.println("Object is instance of ServiceRegistration");
	}
	else {
	    System.out.println("Object is NOT an instance of ServiceRegistration");
	}

	// Add the LookupService to our list
	_registrations.put(lookupService, registration);
    }


    // This thread does nothing but sleep; insures that VM doesn't exit
    public void run() {
	while (true) {
	    try {
		Thread.sleep(1000000);
	    } 
	    catch (InterruptedException exception) {
	    }
	}
    }

    // Create a new HelloWorldService and start its thread
    public static void main(String args[]) {
	try {
	    HelloWorldService service = new HelloWorldService();
	    new Thread(service).start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create service: " + 
			       exception.getMessage());
	}
    }
}

