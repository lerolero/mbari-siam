// Define communication protocol that allows the proxy to talk to
// the backend service

package corejini.chapter5;

import java.rmi.Remote;
import java.rmi.RemoteException;



public interface BackendProtocol extends Remote {
    public String fetchString() throws RemoteException;
}


