rmmod xr788_0
rmmod xr788_1
