rmmod sa1100api
rm -rf /dev/spi0
