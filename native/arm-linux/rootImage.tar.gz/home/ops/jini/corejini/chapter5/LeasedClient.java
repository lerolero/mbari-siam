// Extend the client to renew its event registration leases

package corejini.chapter5;

import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.RemoteEventListener;
import net.jini.core.event.EventRegistration;
import net.jini.core.lease.Lease;
import net.jini.core.lease.UnknownLeaseException;
import java.util.ArrayList;
import java.io.IOException;
import java.rmi.RemoteException;


public class LeasedClient extends EventClient {

    protected ArrayList _eventRegs = new ArrayList();
    protected Thread _leaseThread = null;
    protected final long _padTime = 20 * 1000;

    public LeasedClient() throws RemoteException, IOException {
    }


    // When we register for events, add the event's registration to 
    // set of managed registrations.
    protected void registerForEvents(ServiceRegistrar lookupService) 
	throws RemoteException {

	System.out.println("LeasedClient.registerForEvents()...");

	EventRegistration evReg = 
	    lookupService.notify(_template, 
				 ServiceRegistrar.TRANSITION_NOMATCH_MATCH, 
				 _eventListener, null, LEASE_TIME);
	
	_eventRegs.add(evReg);
	_leaseThread.interrupt();
    }


    // Run maintains our leases
    public void run() {
	while (true) {
	    try {
		long sleepTime = computeSleepTime();
                System.out.println("Sleep for " + sleepTime / 1000 + " secs");
		Thread.sleep(sleepTime);
		renewLeases();
	    }
	    catch (InterruptedException exception) {
	    }
	}
    }

    // Figure out how long to sleep
    protected synchronized long computeSleepTime() {
	long soonestExpiration = Long.MAX_VALUE;
	for (int i = 0, size = _eventRegs.size(); i < size; i++) {
	    Lease lease = ((EventRegistration )_eventRegs.get(i)).getLease();

	    if (lease.getExpiration() - _padTime 
		< soonestExpiration) {
		soonestExpiration = lease.getExpiration() - _padTime;
	    }
	}

	long now = System.currentTimeMillis();
	if (now >= soonestExpiration) {
	    return 0;
	}
	else {
	    return soonestExpiration - now;
	}
    }

    // Do the lease renewal work
    protected synchronized void renewLeases() {
	long now = System.currentTimeMillis();
	ArrayList deadLeases = new ArrayList();

	for (int i = 0, size = _eventRegs.size(); i < size; i++) {

	    Lease lease = ((EventRegistration )_eventRegs.get(i)).getLease();

	    if (now <= lease.getExpiration() &&
		now >= lease.getExpiration() - _padTime) {
		try {
		    System.out.println("Renewing lease.");
		    lease.renew(LEASE_TIME);
		}
		catch (Exception exception) {
		    System.err.println("Couldn't renew lease: " + 
				       exception.getMessage());

		    deadLeases.add(_eventRegs.get(i));
		}
	    }
	}

	// Clean up dead leases
	for (int i = 0, size = deadLeases.size(); i < size; i++) {
	    _eventRegs.remove(deadLeases.get(i));
	}
    }


    // Start the service
    public static void main(String args[]) {

	try {
	    LeasedClient client = new LeasedClient();
	    client._leaseThread = new Thread(client);
	    client._leaseThread.start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create client: " +
			       exception.getMessage());
	}
    }
}
