insmod -o sa1100_spi sa1100spi.o

