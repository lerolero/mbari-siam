#!/bin/sh

# spi_wiggle.sh - Utility for wiggling SPI chip selects
#             and data lines. 

#!/bin/sh

# spi_wiggle.sh - Wiggle SPI CS and data lines
#                 requires that the SPI driver is loaded

if  test -z $1 || [[ $1 > 5 ]] || [[ $1 < 0 ]];  then
echo
echo "Invalid Chip Select (Valid Range 0-5)"
echo "usage $0 <cs>"
echo
echo "SPI driver must be loaded and initialized:"
echo "$insmod -o sa1100_spi sa1100_spi.o"
echo "$echo 8W0G100S0P0I0L > /dev/spi"
echo
exit
fi

echo cs is $1
echo spi data is "0""$1"
echo "$CS""Q" > /dev/spi
sleep 1
echo "0""$1""=" > /dev/spi
echo done
exit
