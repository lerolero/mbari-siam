// Extend HelloWorldService to renew its service registration leases.

package corejini.chapter5;

import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceRegistration;
import net.jini.core.lease.Lease;
import net.jini.core.lease.UnknownLeaseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import java.rmi.RemoteException;

public class LeasedService extends HelloWorldService {
    protected Thread _leaseThread = null;
    final protected long _padTime = 20 * 1000;

    public LeasedService() throws IOException {
	System.out.println("LeasedService()...");
    }

    
    // Register, and then wake up the lease thread
    protected void registerWithLookup(ServiceRegistrar lookupService) {
	super.registerWithLookup(lookupService);
	_leaseThread.interrupt();
    }

    
    // run() maintains the leases
    public void run() {
	while (true) {
	    try {
		long sleepTime = computeSleepTime();
		Thread.sleep(sleepTime);
		renewLeases();
	    }
	    catch (InterruptedException exception) {
		// A new LookupService has been detected and registered; 
		// so we'll just recompute sleepTime 
	    }
	}
    }


    // Figure out how long to sleep
    protected synchronized long computeSleepTime() {
	long soonestExpiration = Long.MAX_VALUE;
	Iterator iterator = _registrations.values().iterator();
	while (iterator.hasNext()) {
            System.out.println("computeSleepTime() - get registration");
            Object object = iterator.next();

	    if (object instanceof ServiceRegistration) {
		System.out.println("object is a ServiceRegistration");
	    }
	    else {
		System.out.println("object is " + object.getClass().getName());
	    }

            ServiceRegistration registration = (ServiceRegistration )object;

	    Lease lease = registration.getLease();

	    if (lease.getExpiration() - _padTime 
		< soonestExpiration) {
		soonestExpiration = lease.getExpiration() - _padTime;
	    }
	}

	long now = System.currentTimeMillis();
	if (now >= soonestExpiration) {
	    return 0;
	}
	else {
	    return soonestExpiration - now;
	}
    }


    // Do the work of lease renewal
    protected synchronized void renewLeases() {
	long now = System.currentTimeMillis();
	ArrayList deadLeases = new ArrayList();
	Iterator keys = _registrations.keySet().iterator();
	while (keys.hasNext()) {

	    ServiceRegistrar lookupService = 
		(ServiceRegistrar )keys.next();

	    ServiceRegistration registration = 
		(ServiceRegistration )_registrations.get(lookupService);

	    Lease lease = registration.getLease();

	    if (now <= lease.getExpiration() &&
		now >= lease.getExpiration() - _padTime) {
		try {
		    System.out.println("Renewing lease.");
		    lease.renew(LEASE_TIME);
		}
		catch (Exception exception) {
		    System.err.println("Couldn't renew lease: " + 
				       exception.getMessage());

		    deadLeases.add(lookupService);
		}
	    }
	}

	// Clean up dead leases
	for (int i = 0, size = deadLeases.size(); i < size; i++) {
	    _registrations.remove(deadLeases.get(i));
	}
    }


    // Create the service and start the leasing thread
    public static void main(String args[]) {
	try {
	    System.out.println("Creating service...");
	    LeasedService service = new LeasedService();
	    System.out.println("Creating thread...");
	    service._leaseThread = new Thread(service);
	    System.out.println("Starting thread...");
	    service._leaseThread.start();
	}
	catch (IOException exception) {
	    System.out.println("Couldn't create service: " + 
			       exception.getMessage());
	}
    }
}



	    
