#!/bin/sh

# spi_cs.sh - Utility for wiggling SPI chip selects
#             and data lines. 


if test -z $1; then
echo
echo "Invalid Chip Select (Valid Range 0-5)"
echo "usage $0 <cs>"
echo "Remember to init SPI driver"
echo "e.g. echo 8W0G100S0P0I1L > /dev/spi"
echo
exit
fi


CS0="0"
CS1="1"
CS2="2"
CS3="3"
CS4="4"
CS5="5"


if ( [ $1 = $CS0 ] ) then
#echo CS0
echo 0x70 > /proc/cpu/registers/GPCR
echo 00= > /dev/spi
elif ( [ $1 = $CS1 ] ) then
#echo CS1
echo 0x70 > /proc/cpu/registers/GPCR
echo 0x10 > /proc/cpu/registers/GPSR
echo 01= > /dev/spi
elif ( [ $1 = $CS2 ] ) then
#echo CS2
echo 0x70 > /proc/cpu/registers/GPCR
echo 0x20 > /proc/cpu/registers/GPSR
echo 02= > /dev/spi
elif ( [ $1 = $CS3 ] ) then
#echo CS3
echo 0x70 > /proc/cpu/registers/GPCR
echo 0x30 > /proc/cpu/registers/GPSR
echo 03= > /dev/spi
elif ( [ $1 = $CS4 ] ) then
#echo CS4
echo 0x70 > /proc/cpu/registers/GPCR
echo 0x40 > /proc/cpu/registers/GPSR
echo 04= > /dev/spi
elif ( [ $1 = $CS5 ] ) then
#echo CS5
echo 0x70 > /proc/cpu/registers/GPCR
echo 0x50 > /proc/cpu/registers/GPSR
echo 05= > /dev/spi
else
echo
echo "Invalid Chip Select (Valid Range 0-5)"
echo
fi

